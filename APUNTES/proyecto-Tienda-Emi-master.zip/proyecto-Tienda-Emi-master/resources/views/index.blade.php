@extends('adminlte::page')

@section('title', 'Inicio')

@section('content_header')
<h1>titulo</h1>
@stop

@section('content')
<p>index</p>
@stop

@section('css')
    <link rel="stylesheet" href="css/home.css">
@stop

@section('js')
   
@stop