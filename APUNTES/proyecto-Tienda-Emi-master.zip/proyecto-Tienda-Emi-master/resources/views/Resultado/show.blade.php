@extends('adminlte::page')

@section('title', 'Inicio')

@section('content_header')
<h1>titulo</h1>
@stop

@section('content')
<p>show</p>
<div >

    <div class="container " style="background-color: white">
        <div class="row justify-content-center border border-primary rounded-top">
            <div class="col justify-content-center">
                
                <div class="row justify-content-center mt-2 text-center">
                    <div class="col">
                        <h3 class="font-weight-bold">TIENDA DE ACCESORIOS PARA AUTOS "ACCESORIOS EMI"</h3>
                    </div>
                </div>

            </div>
        </div>

        <div class="row justify-content-center border border-primary  border-top-0 border-bottom-0">
            <div class="col justify-content-center">
                
            </div>
        </div>  
              
    </div>

</div>
@stop

@section('css')
    <link rel="stylesheet" href="css/home.css">
@stop

@section('js')
   
@stop