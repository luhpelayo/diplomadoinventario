@extends('adminlte::page')

@section('title', 'Inicio')

@section('content_header')
<h1>mostrar Notas De Salida</h1>
@stop

@section('content')
<p>bienvenido</p>
@stop

@section('css')
    <link rel="stylesheet" href="css/home.css">
@stop

@section('js')
   
@stop